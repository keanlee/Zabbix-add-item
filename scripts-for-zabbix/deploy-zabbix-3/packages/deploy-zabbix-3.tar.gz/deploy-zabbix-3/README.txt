    Thank for you use this script to deploy zabbix-server, 
this script can be help you deploy zabbix3 on CentOS 7. This script 
also can upgrade zabbix 3.0 to 3.2 or downgrade zabbix 3.2 to 3.0 ,
you can execute this script again and choose a new version to install 
when you want upgrade or downgrade, but be note: upgrade and downgrade 
will be delete all data of before
