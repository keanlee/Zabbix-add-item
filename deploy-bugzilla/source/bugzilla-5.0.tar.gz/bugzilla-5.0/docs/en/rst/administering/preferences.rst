.. _default-preferences:

Default Preferences
###################

Each user of Bugzilla can set certain preferences about how they want
Bugzilla to behave. Here, you can say whether or not each of the possible
preferences is available to the user and, if it is, what the default value
is.

