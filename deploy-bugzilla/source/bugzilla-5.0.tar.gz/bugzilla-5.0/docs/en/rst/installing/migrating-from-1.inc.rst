.. This file is included in multiple places, so can't have labels as they
   appear as duplicates.
   
The procedure to migrate to Git is as follows. The idea is to switch version
control systems without changing the version of Bugzilla you are using,
to minimise the risk of conflict or problems. Any upgrade can then
happen as a separate step.
