.. _apis:

WebService API Reference
========================

This Bugzilla installation has the following WebService APIs available
(as of the last time you compiled the documentation):

.. toctree::
   :glob:

   core/v*/index
   ../extensions/*/api/v*/index
